﻿namespace UniversityCourseResultManagementSystem.Models
{
    public class Day
    {
        public int DayId { get; set; }
        public string Name { get; set; }
    }
}