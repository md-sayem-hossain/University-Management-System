# University-Management-System

ASP.NET MVC 5 based University Management System

We have created a University Management System, which can be used by students as well as teachers to keep track of and register for courses, grade students and trace results across various semesters.

The project makes use of a ASP.NET MVC5, Entity Framework, MS SQL Server 2012, C#, HTML, CSS, and JavaScript. The system makes use of MS SQL Server 2012 to store the user information, and HTML/CSS for creating a user friendly interface. 

It has 14 Layouts or features:

01.Save Department.      
02. View All Departments.    
03.Save Course.
04. Save Teacher.        
05. Course Assign to Teacher 
06. View Course Statics
07. Register Student     
08. Allocate Classrooms      
09. View Class Schedule and Room Allocation Information
10. Enroll In a Course   
11. Save Student Result      
12. View Result

